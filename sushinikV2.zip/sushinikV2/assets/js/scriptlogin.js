function toggleForms() {
    document.getElementById('login').classList.toggle('active');
    document.getElementById('register').classList.toggle('active');
  }