// Smooth scroll
const links = document.querySelectorAll('a[href^="#"]');
links.forEach(link => {
link.addEventListener('click', e => {
e.preventDefault();
document.querySelector(link.getAttribute('href'))
.scrollIntoView({ behavior: 'smooth' });
});
});


// Prenotazione demo
const form = document.getElementById('bookingForm');
const message = document.getElementById('bookingMessage');


form.addEventListener('submit', e => {
e.preventDefault();
message.textContent = 'Prenotazione inviata con successo!';
form.reset();
});