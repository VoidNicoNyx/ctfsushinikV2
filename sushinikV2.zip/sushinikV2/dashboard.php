<?php
// dashboard.php

require_once __DIR__ . '/server/session.php';

// 🔒 Accesso solo se loggato
if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
    header('Location: pages/login.html');
    exit;
}

// 📂 Percorso reale del file
$filePath = __DIR__ . '/public/img.png';

// ❌ Se il file non esiste
if (!file_exists($filePath)) {
    http_response_code(404);
    exit('File non trovato');
}

// ⬇️ Forza download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="img.png"');
header('Content-Length: ' . filesize($filePath));
header('Cache-Control: no-store');
header('Pragma: no-cache');
header('Expires: 0');

readfile($filePath);
exit;

