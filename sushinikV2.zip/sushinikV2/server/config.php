<?php
// server/config.php

define('ADMIN_EMAIL', 'admin@sushinik.it');

define('ADMIN_PASSWORD_HASH', '$2y$10$5Yz5bP4L9U2Y7N7CkYt8mO3T4kZ8cJXxQ7V5VqP4F7l3bYJ1m');