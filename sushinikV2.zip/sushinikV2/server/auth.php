<?php
// server/auth.php

session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../pages/login.html');
    exit;
}

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (
    $email === ADMIN_EMAIL &&
    password_verify($password, ADMIN_PASSWORD_HASH)
) {
    session_regenerate_id(true);
    $_SESSION['logged'] = true;
    $_SESSION['email'] = $email;

    header('Location: ../dashboard.php');
    exit;
}

header('Location: ../pages/login.html?error=1');
exit;
