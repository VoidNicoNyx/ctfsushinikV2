<?php
// server/session.php

session_start();

if (!isset($_SESSION['logged']) || $_SESSION['logged'] !== true) {
    header('Location: pages/login.html');
    exit;
}
